import plotly.express as px
import streamlit as st
import pandas as pd
import altair as alt

st.title("Corruption Rate Of African Countries")
df = pd.DataFrame({
    'Countries': ['Nigeria', 'Seychelles', 'South Sudan','Botswana','Libya','Mauritius'],
    'CorruptIndex2020': [25, 66, 12,60,17,53],
    'CorruptIndex2021': [24, 70, 11,55,17,54]
})

df

fig = px.scatter(df, x="Countries", y=["CorruptIndex2020", "CorruptIndex2021"], title="Corruption Index Of African Countries")
fig.show()

st.header("Representation on a Scatter Chart")
